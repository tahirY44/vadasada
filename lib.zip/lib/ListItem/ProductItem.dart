class ProductItem {
  String title, images, heroId;
  int id, price, discounted;

  ProductItem(
      {this.id,
      this.title,
      this.images,
      this.heroId,
      this.price,
      this.discounted});
}
