class CategoryItem {
  String title;
  int id;
  bool isActive;

  CategoryItem({
    this.id,
    this.title,
    this.isActive,
  });
}
