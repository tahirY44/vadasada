class userCheckoutData {
  String name, email, mobile, address, instruction;
  String city_id;

  userCheckoutData(
      {this.name,
      this.email,
      this.mobile,
      this.address,
      this.instruction,
      this.city_id});
}
